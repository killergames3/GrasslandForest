#!/bin/sh
# Solo admite identificadores fijos de navegador, nunca URLs ni comandos.
case "${1:-system}" in
    system) if [ -x /usr/bin/xdg-open ]; then exec /usr/bin/xdg-open 'https://app.grasslandforest.com/'; fi ;;
    brave) set -- /usr/bin/brave-browser /opt/brave.com/brave/brave-browser ;;
    chrome) set -- /usr/bin/google-chrome-stable /usr/bin/google-chrome ;;
    edge) set -- /usr/bin/microsoft-edge-stable /usr/bin/microsoft-edge ;;
    firefox) set -- /usr/bin/firefox /snap/bin/firefox ;;
    opera) set -- /usr/bin/opera /usr/bin/opera-stable ;;
    chromium) set -- /usr/bin/chromium /usr/bin/chromium-browser /snap/bin/chromium ;;
    *) printf '%s\n' 'Choose: system, brave, chrome, edge, firefox, opera or chromium.' >&2; exit 2 ;;
esac
# Si no existe xdg-open, detectar una ruta conocida para la elección system.
if [ "${1:-system}" = system ]; then
    set -- /usr/bin/brave-browser /opt/brave.com/brave/brave-browser /usr/bin/google-chrome-stable /usr/bin/google-chrome /usr/bin/microsoft-edge-stable /usr/bin/microsoft-edge /usr/bin/firefox /snap/bin/firefox /usr/bin/opera /usr/bin/opera-stable /usr/bin/chromium /usr/bin/chromium-browser /snap/bin/chromium
fi
for browser in "$@"; do
    if [ -x "$browser" ]; then
        case "$browser" in
            */firefox) exec "$browser" '-new-window' 'https://app.grasslandforest.com/' ;;
            *) exec "$browser" '--new-window' 'https://app.grasslandforest.com/' ;;
        esac
    fi
done
printf '%s\n' 'Install Brave, Chrome, Edge, Firefox, Opera or Chromium to start Grassland Forest.' >&2
exit 1
