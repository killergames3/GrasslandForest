#!/bin/sh
# No acepta URLs, comandos, perfiles ni flags recibidos de otras aplicaciones.
for browser in /usr/bin/brave-browser /opt/brave.com/brave/brave-browser /usr/bin/google-chrome-stable /usr/bin/google-chrome /usr/bin/microsoft-edge-stable /usr/bin/microsoft-edge /usr/bin/firefox /snap/bin/firefox /usr/bin/opera /usr/bin/opera-stable /usr/bin/chromium /usr/bin/chromium-browser /snap/bin/chromium; do
    if [ -x "$browser" ]; then
        case "$browser" in
            */firefox) exec "$browser" '-new-window' 'https://app.grasslandforest.com/' ;;
            *) exec "$browser" '--new-window' 'https://app.grasslandforest.com/' ;;
        esac
    fi
done
printf '%s\n' 'Install Brave, Chrome, Edge, Firefox, Opera or Chromium to start Grassland Forest.' >&2
exit 1
