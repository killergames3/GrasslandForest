Grassland Forest — native macOS build kit
This is source code, not a compiled .app. Requires macOS 13 or later and Node.js 24.
Run npm ci, npm test, then npm run build:mac -- --config.mac.identity=-.
The result contains the same native session restore, Sign out and Switch account controls as Windows and Linux.
The dash identity produces an ad-hoc signature, not an Apple Developer ID signature or notarization.
For public distribution, use your Apple Developer ID signing identity and notarization credentials.
Alternatively put this kit in a GitHub repository and run its Build native clients workflow.
The workflow is manual and does not publish or deploy anything.
No wallet private keys, Android signing keys, backend environment files or user cookies are included.
